<?php

include('config.php');

class first {

    public function get_data($param = '', $table = '', $con = '') {
        global $conn;

        if (!empty($param)) {

            $select_prm = implode(",", $param);
        } else {
            $select_prm = "*";
        }

        if (!empty($con)) {

            function implodeItem(&$item, $key) {
                if (!ctype_digit($item)) {
                    $item = "'" . $item . "'";
                }
                $item = $key . "=" . $item;
            }

            array_walk($con, "implodeItem");
            $condition = "where " . implode(' AND ', $con);
        } else {

            $condition = "";
        }

        $sql = "SELECT " . $select_prm . " FROM " . $table . " " . $condition . "";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {

            while ($row[] = $result->fetch_assoc()) {
                
            }

            return $row;
        }
    }

}

?>
