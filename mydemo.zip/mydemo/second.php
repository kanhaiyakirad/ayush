<?php

include('first.php');

class second extends first {

    public function set_owner() {


        return $this->get_data('', 'mydemo', array('id' => 2));
        
    }

}

?>