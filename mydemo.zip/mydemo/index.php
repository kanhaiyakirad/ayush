<?php

include('second.php');
$ncart = new second;
$url = str_replace('/mydemo/', '', $_SERVER['REQUEST_URI']);
$urlParams = explode('/', $url);
//print_r($urlParams);die;
$functionName = $urlParams[0];
$parm = $urlParams[1];
$data = $ncart->$functionName();

?>
<table border="2">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Address</th>
    </tr>
    <?php foreach ($data as $row){ if(!empty($row)){?>
    <tr>
    <td><?php echo $row['id']?></td>
    <td><?php echo $row['name']?></td>
    <td><?php echo $row['address']?></td>
    </tr>
    <?php }}?>
</table>